<?php $__env->startSection('content'); ?>

<h2>Detalhes da Disciplina</h2>

<a href="<?php echo e(route('discipline.index', ['course' => $discipline->course_id])); ?>">
    <button type="button">Listar disciplinas</button>
</a>



ID: <?php echo e($discipline->id); ?><br>
Nome da disciplina: <?php echo e($discipline->name); ?><br>
Descrição: <?php echo e($discipline->description); ?><br>
Curso: <?php echo e($discipline->course->name); ?><br>
Cadastrado: <?php echo e(\Carbon\Carbon::parse($discipline->created_at)->format('d/m/Y H:i:s')); ?><br>
Editado: <?php echo e(\Carbon\Carbon::parse($discipline->updated_at)->format('d/m/Y H:i:s')); ?><br><br>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\requerimento_faculdade_meta\resources\views/discipline/show.blade.php ENDPATH**/ ?>