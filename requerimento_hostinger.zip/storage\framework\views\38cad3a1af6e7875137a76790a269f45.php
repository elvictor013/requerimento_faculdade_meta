<?php $__env->startSection('content'); ?>
<main class="container my-5">
    <?php if (isset($component)) { $__componentOriginal5194778a3a7b899dcee5619d0610f5cf = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5194778a3a7b899dcee5619d0610f5cf = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.alert','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5194778a3a7b899dcee5619d0610f5cf)): ?>
<?php $attributes = $__attributesOriginal5194778a3a7b899dcee5619d0610f5cf; ?>
<?php unset($__attributesOriginal5194778a3a7b899dcee5619d0610f5cf); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5194778a3a7b899dcee5619d0610f5cf)): ?>
<?php $component = $__componentOriginal5194778a3a7b899dcee5619d0610f5cf; ?>
<?php unset($__componentOriginal5194778a3a7b899dcee5619d0610f5cf); ?>
<?php endif; ?>
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1 class="fw-bold mb-0">Lista de Funcionários</h1>
        <a href="<?php echo e(route('funcionario.create')); ?>"
            class="btn btn-sm btn-primary"
            type="button">
            <i class="fas fa-user-plus"></i> Cadastrar Funcionário
        </a>
    </div>
    <div class="table-responsive bg-white rounded shadow-sm p-3">
        <table class="table table-hover align-middle mb-0">
            <thead class="table-light">
                <tr>
                    <th scope="col">Nome Completo</th>
                    <th scope="col">CPF</th>
                    <th scope="col">Email</th>
                    <th scope="col">Função</th>
                    <th scope="col" class="text-center" style="width: 130px;">Ações</th>
                </tr>
            </thead>
            <tbody>

                <?php $__empty_1 = true; $__currentLoopData = $funcionarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $funcionario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($funcionario->user->name); ?></td>
                    <td><?php echo e($funcionario->cpf); ?></td>
                    <td><?php echo e($funcionario->user->email); ?></td>
                    <td><?php echo e($funcionario->tipo_funcionario); ?></td>
                    <td class="text-center">
                        <a href="<?php echo e(route('funcionario.show', ['funcionario' => $funcionario->id])); ?>"
                            class="btn btn-sm btn-outline-primary btn-icon"
                            title="Visualizar"
                            type="button">
                            <i class="fas fa-eye"></i>
                        </a>

                        <a href="<?php echo e(route('funcionario.edit', $funcionario->id)); ?>"
                            class="btn btn-sm btn-outline-warning btn-icon"
                            title="Editar">
                            <i class="fas fa-edit"></i>
                        </a>

                        <form method="POST" action="<?php echo e(route('funcionario.destroy' , ['funcionario' => $funcionario->id])); ?>" class="d-inline">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('delete'); ?>

                            <button class="btn btn-sm btn-outline-danger btn-icon"
                                title="Apagar"
                                type="submit"
                                onclick="return confirm('Tem certeza que deseja apagar esse registro?')">
                                <i class="fas fa-trash-alt"></i>
                            </button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="5">
                        <div class="alert alert-danger mb-0 text-center">
                            Nenhum funcionário cadastrado.
                        </div>
                    </td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\requerimento_faculdade_meta\resources\views/funcionario/index.blade.php ENDPATH**/ ?>