<?php $__env->startSection('content'); ?>

<div class="card mt-4 mb-4 border-light shadow">
    <div class="card-header hstack gap-2">
        <h5 class="mb-0">Editar Funcionário</h5>
    </div>

    <div class="card-body">
        <?php if (isset($component)) { $__componentOriginal5194778a3a7b899dcee5619d0610f5cf = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5194778a3a7b899dcee5619d0610f5cf = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.alert','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5194778a3a7b899dcee5619d0610f5cf)): ?>
<?php $attributes = $__attributesOriginal5194778a3a7b899dcee5619d0610f5cf; ?>
<?php unset($__attributesOriginal5194778a3a7b899dcee5619d0610f5cf); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5194778a3a7b899dcee5619d0610f5cf)): ?>
<?php $component = $__componentOriginal5194778a3a7b899dcee5619d0610f5cf; ?>
<?php unset($__componentOriginal5194778a3a7b899dcee5619d0610f5cf); ?>
<?php endif; ?>

        <form action="<?php echo e(route('funcionario.update', $funcionario->id)); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>

            <div class="row g-3">

                <div class="col-md-6">
                    <label for="name" class="form-label">Nome:</label>
                    <input type="text" name="name" class="form-control" id="name"
                        placeholder="Nome Completo" value="<?php echo e(old('name', $funcionario->user->name)); ?>">
                </div>

                <div class="col-md-6">
                    <label for="email" class="form-label">E-mail:</label>
                    <input type="email" name="email" class="form-control" id="email"
                        placeholder="Melhor e-mail do usuário" value="<?php echo e(old('email', $funcionario->user->email)); ?>">
                </div>

                <div class="col-md-6">
                    <label for="cpf" class="form-label">CPF:</label>
                    <input type="text" name="cpf" class="form-control" id="cpf"
                        placeholder="00000000000" value="<?php echo e(old('cpf', $funcionario->cpf)); ?>">
                </div>

                <div class="col-md-6">
                    <label for="tipo_funcionario" class="form-label">Tipo do Funcionário:</label>
                    <select class="form-select" id="tipo_funcionario" name="tipo_funcionario" required>
                        <option value="" disabled>Selecione um papel</option>
                        <?php
                        $roles = [
                            'coordenador' => 'Funcionário',
                            'admin' => 'Administrador',
                            'atendente' => 'Atendente',
                            'professor' => 'Professor',
                            'pedagogo' => 'Pedagogo',
                            'coordenador_curso' => 'Coordenador de Curso',
                            'coordenador_estagio' => 'Coordenador de Estágio',
                            'gerente_academico' => 'Gerente Acadêmico',
                            'diretor_academico' => 'Diretor Acadêmico',
                            'vice_diretor' => 'Vice-Diretor',
                            'financeiro' => 'Financeiro',
                            'secretario' => 'Secretário(a)',
                        ];
                        ?>
                        <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($key); ?>"
                            <?php echo e((old('tipo_funcionario', $funcionario->tipo_funcionario) == $key) ? 'selected' : ''); ?>>
                            <?php echo e($value); ?>

                        </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <div class="col-md-6">
                    <label for="setor_id" class="form-label">Setor:</label>
                    <select class="form-select" id="setor_id" name="setor_id" required>
                        <option value="" disabled>Selecione o setor</option>
                        <?php $__currentLoopData = $setores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $setor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($setor->id); ?>"
                            <?php echo e((old('setor_id', $funcionario->setor_id) == $setor->id) ? 'selected' : ''); ?>>
                            <?php echo e($setor->descricao); ?>

                        </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <div class="col-md-6">
                    <label for="password" class="form-label">Senha:</label>
                    <div class="input-group">
                        <input type="password" name="password" class="form-control" id="password"
                            placeholder="Deixe em branco para não alterar">
                        <span class="input-group-text" role="button"
                            onclick="togglePassword('password', this)">
                            <i class="bi bi-eye"></i>
                        </span>
                    </div>
                </div>

                <div class="col-md-6">
                    <label for="password_confirmation" class="form-label">Confirmar Senha:</label>
                    <div class="input-group">
                        <input type="password" name="password_confirmation" class="form-control"
                            id="password_confirmation" placeholder="Confirme a senha">
                        <span class="input-group-text" role="button"
                            onclick="togglePassword('password_confirmation', this)">
                            <i class="bi bi-eye"></i>
                        </span>
                    </div>
                </div>

            </div>

            <div class="d-flex justify-content-end mt-4">
                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-save me-1"></i> Atualizar
                </button>
            </div>

        </form>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\requerimento_faculdade_meta\resources\views/funcionario/edit.blade.php ENDPATH**/ ?>