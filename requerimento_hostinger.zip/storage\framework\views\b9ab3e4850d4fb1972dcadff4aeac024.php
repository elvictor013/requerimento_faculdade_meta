

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Detalhes do Funcionario</h1>

    <div class="card">
        <div class="card-body">
            <p><strong>ID:</strong> <?php echo e($funcionario->id); ?></p>
            <p><strong>Nome:</strong> <?php echo e($funcionario->user->name); ?></p>
            <p><strong>Email:</strong> <?php echo e($funcionario->user->email); ?></p>
            <p><strong>CPF:</strong> <?php echo e($funcionario->cpf); ?></p>
            <p><strong>Tipo de Funcionario:</strong> <?php echo e($funcionario->tipo_funcionario); ?></p>
            <p><strong>Data de Criação:</strong> <?php echo e($funcionario->created_at->format('d/m/Y H:i')); ?></p>
            <p><strong>Data de Edição:</strong> <?php echo e($funcionario->updated_at->format('d/m/Y H:i')); ?></p>
            

            
            <a href="<?php echo e(route('requerimentos.index')); ?>" class="btn btn-secondary">Voltar</a>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\requerimento_faculdade_meta\resources\views/funcionario/show.blade.php ENDPATH**/ ?>