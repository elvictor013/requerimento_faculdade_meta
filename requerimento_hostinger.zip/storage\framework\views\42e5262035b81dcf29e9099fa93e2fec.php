<?php $__env->startSection('content'); ?>
<div class="container">
    <h2>Permissões</h2>

    <form action="<?php echo e(route('permissions.store')); ?>" method="POST" class="mb-4">
        <?php echo csrf_field(); ?>
        <div class="input-group">
            <input type="text" name="name" class="form-control" placeholder="Nome da permissão">
            <button class="btn btn-primary">Adicionar</button>
        </div>
    </form>

    <table class="table">
        <thead>
            <tr>
                <th>Nome</th>
                <th>Ações</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($permission->name); ?></td>
                <td>
                    <form action="<?php echo e(route('permissions.destroy', $permission->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button class="btn btn-danger btn-sm">Excluir</button> <br>
                    </form>
                    
                    <br><button class="btn btn-warning btn-sm">Editar</button>
                    <button class="btn btn-primary btn-sm">Visualizar</button>
                    <button class="btn btn-info btn-sm">Permissoes</button>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\requerimento_faculdade_meta\resources\views/admin/permissions/index.blade.php ENDPATH**/ ?>