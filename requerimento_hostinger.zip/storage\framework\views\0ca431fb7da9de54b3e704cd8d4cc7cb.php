<?php $__env->startSection('content'); ?>

<div class="card mt-4 mb-4 border-light shadow">

    <div class="card-header hstack gap-2">
        <span>Cadastrar Funcionario</span>
        <span class="ms-auto d-sm-flex flex-row">
            <a href="<?php echo e(route('atendimento.index')); ?>" class="btn btn-info btn-sm me-1">Tela Inicial</a>
        </span>
    </div>

    <div class="card-body">
        <?php if (isset($component)) { $__componentOriginal5194778a3a7b899dcee5619d0610f5cf = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5194778a3a7b899dcee5619d0610f5cf = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.alert','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5194778a3a7b899dcee5619d0610f5cf)): ?>
<?php $attributes = $__attributesOriginal5194778a3a7b899dcee5619d0610f5cf; ?>
<?php unset($__attributesOriginal5194778a3a7b899dcee5619d0610f5cf); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5194778a3a7b899dcee5619d0610f5cf)): ?>
<?php $component = $__componentOriginal5194778a3a7b899dcee5619d0610f5cf; ?>
<?php unset($__componentOriginal5194778a3a7b899dcee5619d0610f5cf); ?>
<?php endif; ?>

        <form action="<?php echo e(route('atendimento.store')); ?>" method="POST" class="row g-3">
            <?php echo csrf_field(); ?>
            <?php echo method_field('POST'); ?>

            <div class="col-md-12">
                <label for="name" class="form-label">Nome:</label>
                <input type="text" name="name" class="form-control" id="name" placeholder="Nome Completo" value="<?php echo e(old('name')); ?>">
            </div>

            <div class="col-md-12">
                <label for="email" class="form-label">E-mail:</label>
                <input type="email" name="email" class="form-control" id="email" placeholder="Melhor E-mail do Usuário" value="<?php echo e(old('email')); ?>">
            </div>

            <!-- cadastar CPF -->

            <div class="col-md-12">
                <label for="cpf" class="form-label">CPF:</label>
                <input type="text" name="cpf" class="form-control" id="cpf" placeholder="00000000000" value="<?php echo e(old('cpf')); ?>">

            </div>

            <!-- tipo de funcionario -->

            <div class="col-md-12">
                <label class="form-label" for="tipo_funcionario">Tipo do Funcionário</label>
                <select class="form-select" id="tipo_funcionario" name="tipo_funcionario" required>
                    <option value="" disabled selected>Selecione um papel</option>
                    <option value="coordenador">Funcionario</option>
                    <option value="admin">Administrador</option>
                    <option value="atendente">Atendente</option>
                    <option value="professor">Professor</option>
                    <option value="pedagogo">Pedagogo</option>
                    <option value="coordenador_curso">Coordenador de Curso</option>
                    <option value="coordenador_estagio">Coordenador de Estágio</option>
                    <option value="gerente_academico">Gerente Acadêmico</option>
                    <option value="diretor_academico">Diretor Acadêmico</option>
                    <option value="vice_diretor">Vice-Diretor</option>
                    <option value="financeiro">Financeiro</option>
                    <option value="secretario">Secretário(a)</option>
                </select>
            </div>

            <!-- setor do funcionario -->

            <div class="mb-3">
                <label class="form-label fw-semibold" for="setor_id">Setor</label>
                <select class="form-select" id="setor_id" name="setor_id" required>
                    <option value="" disabled selected>Selecione o setor</option>
                    <?php $__currentLoopData = $setores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $setor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($setor['id']); ?>"><?php echo e($setor['descricao']); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>


            <div class="col-md-6">
                <label for="password" class="form-label">Senha:</label>
                <div class="input-group">
                    <input type="password" name="password" class="form-control" id="password" placeholder="Senha com no mínimo 6 caracteres" value="<?php echo e(old('password')); ?>">
                    <span class="input-group-text" role="button" onclick="togglePassword('password', this)"><i class="bi bi-eye"></i></span>
                </div>
            </div>

            <div class="col-md-6">
                <label for="password_confirmation" class="form-label">Confirmar Senha:</label>
                <div class="input-group">
                    <input type="password" name="password_confirmation" class="form-control" id="password_confirmation" placeholder="Confirmar a senha" value="<?php echo e(old('password_confirmation')); ?>">
                    <span class="input-group-text" role="button" onclick="togglePassword('password_confirmation', this)"><i class="bi bi-eye"></i></span>
                </div>
            </div>

            <div class="col-12">
                <button type="submit" class="btn btn-success btn-sm">Cadastrar</button>
            </div>
        </form>
    </div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\requerimento_faculdade_meta\resources\views/atendimento/create.blade.php ENDPATH**/ ?>