<?php $__env->startPush('styles'); ?>
<style>
    body {
        font-family: "Montserrat", sans-serif;
        background-color: #f3f5f9;
        color: #1a1a1a;
        min-height: 100vh;
        padding-top: 1.5rem;
        padding-bottom: 1.5rem;
    }

    .container {
        max-width: 720px;
        background: white;
        padding: 2rem;
        border-radius: 0.5rem;
        box-shadow: 0 0 12px rgb(0 0 0 / 0.1);
    }

    .label {
        font-weight: 600;
        color: #555;
        width: 160px;
        display: inline-block;
    }

    .value {
        font-weight: 500;
        color: #222;
    }

    .description {
        margin-top: 1rem;
        padding: 1rem;
        background-color: #e9ecef;
        border-radius: 0.375rem;
        min-height: 100px;
        white-space: pre-wrap;
        font-size: 1rem;
        color: #333;
    }

    .row-item {
        margin-bottom: 0.75rem;
    }

    .btn-top-actions {
        display: flex;
        justify-content: flex-end;
        gap: 1rem;
        margin-bottom: 1.5rem;
        flex-wrap: wrap;
    }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>

<?php if (isset($component)) { $__componentOriginal5194778a3a7b899dcee5619d0610f5cf = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5194778a3a7b899dcee5619d0610f5cf = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.alert','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5194778a3a7b899dcee5619d0610f5cf)): ?>
<?php $attributes = $__attributesOriginal5194778a3a7b899dcee5619d0610f5cf; ?>
<?php unset($__attributesOriginal5194778a3a7b899dcee5619d0610f5cf); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5194778a3a7b899dcee5619d0610f5cf)): ?>
<?php $component = $__componentOriginal5194778a3a7b899dcee5619d0610f5cf; ?>
<?php unset($__componentOriginal5194778a3a7b899dcee5619d0610f5cf); ?>
<?php endif; ?>

<main class="container">
    <h1>Visualizar Requerimento</h1>

    <div class="btn-top-actions">
        <form method="POST" action="<?php echo e(route('requerimentos.atualizarStatus', $requerimento->id)); ?>" class="d-inline">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="status" value="Aprovado">
            <button type="submit" class="btn btn-success">
                <i class="fas fa-check"></i> Aprovar
            </button>
        </form>

        <form method="POST" action="<?php echo e(route('requerimentos.atualizarStatus', $requerimento->id)); ?>" class="d-inline">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="status" value="Reprovado">
            <button type="submit" class="btn btn-danger">
                <i class="fas fa-times"></i> Reprovar
            </button>
        </form>

        <button type="button" class="btn btn-warning" data-bs-toggle="modal" data-bs-target="#encaminharModal">
            <i class="fas fa-share"></i> Encaminhar
        </button>
    </div>

    <div class="row-item"><span class="label">Protocolo:</span> <span class="value"><?php echo e($requerimento->protocolo); ?></span></div>
    <div class="row-item"><span class="label">Aluno:</span> <span class="value"><?php echo e($requerimento->aluno->user->name); ?></span></div>
    <div class="row-item"><span class="label">Matrícula:</span> <span class="value"><?php echo e($requerimento->aluno->matricula); ?></span></div>
    <div class="row-item"><span class="label">Tipo:</span> <span class="value"><?php echo e($requerimento->tipo_requerimento); ?></span></div>
    <div class="row-item"><span class="label">Status:</span> <span class="value"><?php echo e($requerimento->status); ?></span></div>
    <div class="row-item"><span class="label">Curso:</span> <span class="value"><?php echo e($requerimento->categoria->nome ?? 'Não informado'); ?></span></div>
    <div class="row-item"><span class="label">Semestre:</span> <span class="value"><?php echo e($requerimento->semestre); ?></span></div>
    <div class="row-item"><span class="label">Data de Criação:</span> <span class="value"><?php echo e($requerimento->created_at->format('d/m/Y H:i')); ?></span></div>
    <div class="row-item">
        <span class="label">Descrição:</span>
        <div class="description"><?php echo e($requerimento->descricao); ?></div>
    </div>

    <div class="row-item">
        <span class="label">Resposta do setor</span>
        <div class="description"><?php echo e($requerimento->resposta_atendente); ?></div>
    </div>

    <!-- Seu textarea fora do modal -->
    <div class="mb-3">
        <label for="responseText" class="form-label">Mensagem</label>
        <textarea class="form-control" id="responseText" rows="4"
            name="mensagem" placeholder="Digite sua mensagem..."><?php echo e(old('mensagem', $requerimento->mensagem ?? '')); ?></textarea>

    </div>

    <!-- Botão para abrir modal -->
    <button type="button" class="btn btn-primary" id="abrirModal" data-bs-toggle="modal" data-bs-target="#anexoModal">
        <i class="fas fa-paper-plane"></i> Responder
    </button>

    <!-- Modal -->
    <div class="modal fade" id="anexoModal" tabindex="-1" aria-labelledby="anexoModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <form method="POST" action="<?php echo e(route('requerimentos.responderAluno', $requerimento->id)); ?>" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <!-- Campo hidden que vai enviar a mensagem -->
                    <input type="hidden" name="mensagem" id="mensagemInput">

                    <div class="modal-header">
                        <h5 class="modal-title" id="anexoModalLabel">Deseja anexar um arquivo?</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Fechar"></button>
                    </div>

                    <div class="modal-body">
                        <div class="mb-3">
                            <label for="fileInput" class="form-label">Escolha o arquivo</label>
                            <input type="file" name="anexo_resposta" class="form-control" id="fileInput" accept=".pdf,.jpg,.jpeg,.png,.doc,.docx" />
                            <div class="form-text">Tipos permitidos: pdf, jpg, jpeg, png, doc, docx</div>
                        </div>

                        <!-- Exemplo de mostrar a mensagem no modal, mas escondida -->
                        <div id="mensagemEscondida" style="display:none;"></div>
                    </div>

                    <div class="modal-footer">
                        <button type="submit" class="btn btn-primary">Enviar</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Modal de Encaminhamento -->
    <div class="modal fade" id="encaminharModal" tabindex="-1" aria-labelledby="encaminharModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <form method="POST" action="<?php echo e(route('requerimentos.encaminhar', $requerimento->id)); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="modal-header">
                        <h5 class="modal-title">Encaminhar Requerimento</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-semibold" for="setor_id">Setor</label>
                        <select class="form-select" id="setor_id" name="setor_id" required>
                            <option value="" disabled selected>Selecione o setor</option>
                            <?php $__currentLoopData = $setores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $setor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($setor['id']); ?>"><?php echo e($setor['nome']); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-primary">Enviar</button>
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const mensagemInput = document.getElementById('mensagemInput');
            const responseText = document.getElementById('responseText');
            const anexoModal = document.getElementById('anexoModal');
            const mensagemEscondida = document.getElementById('mensagemEscondida');

            // Atualiza o campo hidden sempre que o modal abrir
            anexoModal.addEventListener('show.bs.modal', function() {
                mensagemInput.value = responseText.value;
                mensagemEscondida.textContent = responseText.value; // opcional, mensagem no modal escondida
                console.log('Mensagem copiada para hidden:', mensagemInput.value);
            });

            // No envio, garante que o campo hidden está atualizado
            const form = anexoModal.querySelector('form');
            form.addEventListener('submit', function() {
                mensagemInput.value = responseText.value;
            });
        });
    </script>


    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.setor', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\requerimento_faculdade_meta\resources\views/atendimento/show.blade.php ENDPATH**/ ?>