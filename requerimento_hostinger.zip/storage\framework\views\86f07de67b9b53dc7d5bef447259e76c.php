<?php $__env->startSection('content'); ?>
<br>
<div class="container">
    <h1 class="mb-4">Detalhes do Requerimento</h1>

    <div class="card">
        <div class="card-body">
            <p><strong>Protocolo:</strong> <?php echo e($requerimento->protocolo); ?></p>
            <p><strong>Aluno:</strong> <?php echo e($requerimento->aluno->nome); ?></p>
            <p><strong>Matrícula:</strong> <?php echo e($requerimento->aluno->matricula); ?></p>
            <p><strong>Tipo:</strong> <?php echo e($requerimento->tipo_requerimento); ?></p>
            <p><strong>Descrição:</strong> <?php echo e($requerimento->descricao); ?></p>
            <p><strong>Status:</strong> <?php echo e($requerimento->status); ?></p>

            <p><strong>Curso:</strong>
                <?php echo e($requerimento->categoria->nome ?? 'Não informado'); ?>

            </p>

            <p><strong>Semestre:</strong> <?php echo e($requerimento->semestre); ?></p>
            <p><strong>Data de Criação:</strong> <?php echo e($requerimento->created_at->format('d/m/Y H:i')); ?></p>
            <p><strong>Resposta:</strong></p>

            <?php if($requerimento->resposta_atendente): ?>
            <div class="alert alert-info mt-4">
                <strong>Resposta do Atendente:</strong><br>
                <p><?php echo e($requerimento->resposta_atendente); ?></p>

                <?php if($requerimento->anexo_resposta_atendente): ?>
                <p>
                    <strong>Anexo da Resposta:</strong>
                    <a href="<?php echo e(route('requerimentos.downloadAnexo', $requerimento->id)); ?>" target="_blank">
                        Baixar Anexo da Resposta
                    </a>
                </p>
                <?php endif; ?>

            </div>
            <?php endif; ?>


            <a href="<?php echo e(route('requerimentos.index')); ?>" class="btn btn-secondary mt-3">Voltar</a>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\requerimento_faculdade_meta\resources\views/requerimentos/show.blade.php ENDPATH**/ ?>