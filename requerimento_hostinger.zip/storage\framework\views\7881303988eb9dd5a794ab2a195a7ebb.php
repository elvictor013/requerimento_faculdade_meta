<?php $__env->startSection('content'); ?>
<br>
<h2>Lista de Disciplinas do Curso: <?php echo e($course->name); ?></h2>

<a href="<?php echo e(route('courses.index', ['course' => $course->id])); ?>">
    <button type="button">Cursos</button>
</a><br><br>

<a href="<?php echo e(route('discipline.create', ['course' => $course->id])); ?>">
    <button type="button">Cadastrar Disciplina</button>
</a><br><br>

<?php if (isset($component)) { $__componentOriginal5194778a3a7b899dcee5619d0610f5cf = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5194778a3a7b899dcee5619d0610f5cf = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.alert','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5194778a3a7b899dcee5619d0610f5cf)): ?>
<?php $attributes = $__attributesOriginal5194778a3a7b899dcee5619d0610f5cf; ?>
<?php unset($__attributesOriginal5194778a3a7b899dcee5619d0610f5cf); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5194778a3a7b899dcee5619d0610f5cf)): ?>
<?php $component = $__componentOriginal5194778a3a7b899dcee5619d0610f5cf; ?>
<?php unset($__componentOriginal5194778a3a7b899dcee5619d0610f5cf); ?>
<?php endif; ?>

<?php $__empty_1 = true; $__currentLoopData = $disciplines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $discipline): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        ID: <?php echo e($discipline->id); ?><br>
        Nome da disciplina: <?php echo e($discipline->name); ?><br>
        Descrição: <?php echo e($discipline->description); ?><br>
        Curso: <?php echo e($discipline->course->name); ?><br>
        Cadastrado: <?php echo e(\Carbon\Carbon::parse($discipline->created_at)->format('d/m/Y H:i:s')); ?><br>
        Editado: <?php echo e(\Carbon\Carbon::parse($discipline->updated_at)->format('d/m/Y H:i:s')); ?><br><br>

        <a href="<?php echo e(route('discipline.edit', ['discipline' => $discipline->id])); ?>">
            <button type="button">Editar</button>
        </a>

        <a href="<?php echo e(route('discipline.show', ['discipline' => $discipline->id])); ?>">
            <button type="button">Visualizar</button>
        </a><br><br>

        <form action="<?php echo e(route('discipline.destroy', ['discipline' => $discipline->id])); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('delete'); ?>
            <button type="submit" onclick="return confirm('Tem certeza que deseja apagar este registro?')">Apagar</button>
        </form><br>


    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <p style="color: #f00">Nenhuma disciplina encontrada!</p>
    <?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\requerimento_faculdade_meta\resources\views/discipline/index.blade.php ENDPATH**/ ?>