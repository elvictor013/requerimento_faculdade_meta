<?php $__env->startSection('content'); ?>

<div class="card mt-4 mb-4 border-light shadow">

        <div class="card-header hstack gap-2">
                <span>Visualizar o usuário</span>
                <span class="ms-auto d-sm-flex flex-row">
                        <a href="<?php echo e(route('user.index')); ?>" class="btn btn-info btn-sm me-1">lista de requeriemnto</a>
                        <a href="<?php echo e(route('user.edit', ['user' => $user->id])); ?>" class="btn btn-warning btn-sm me-1">Editar</a>
                        <form method="POST" action="<?php echo e(route('user.destroy' , ['user' => $user->id])); ?>">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('delete'); ?>
                                <button type="submit" class="btn btn-danger btn-sm me-1" onclick="return confirm('tem certeza que deseja apagar esse registro?')">Apagar</button>
                </span>
        </div>

        <div class="card-body">
                <?php if (isset($component)) { $__componentOriginal5194778a3a7b899dcee5619d0610f5cf = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5194778a3a7b899dcee5619d0610f5cf = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.alert','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5194778a3a7b899dcee5619d0610f5cf)): ?>
<?php $attributes = $__attributesOriginal5194778a3a7b899dcee5619d0610f5cf; ?>
<?php unset($__attributesOriginal5194778a3a7b899dcee5619d0610f5cf); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5194778a3a7b899dcee5619d0610f5cf)): ?>
<?php $component = $__componentOriginal5194778a3a7b899dcee5619d0610f5cf; ?>
<?php unset($__componentOriginal5194778a3a7b899dcee5619d0610f5cf); ?>
<?php endif; ?>
                <dl class="row">
                        <dt class="col-sm-3">ID:</dt>
                        <dd class="col-sm-9"><?php echo e($user->id); ?>.</dd>

                        <dt class="col-sm-3">Nome:</dt>
                        <dd class="col-sm-9"><?php echo e($user->name); ?>.</dd>

                        <dt class="col-sm-3">E-mail:</dt>
                        <dd class="col-sm-9"><?php echo e($user->email); ?>.</dd>

                        <dt class="col-sm-3">Solicitado:</dt>
                        <dd class="col-sm-9"><?php echo e(\carbon\carbon::parse ($user->created_at)->format ('d/m/y h:i:s')); ?>.</dd>

                        <dt class="col-sm-3">Editado</dt>
                        <dd class="col-sm-9"><?php echo e(\carbon\carbon::parse ($user->updated_at)->format ('d/m/y h:i:s')); ?>.</dd>
                </dl>
        </div>

        <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\requerimento_faculdade_meta\resources\views/users/show.blade.php ENDPATH**/ ?>