<?php $__env->startSection('content'); ?>
    <h2>Movimentações</h2>
    <a href="<?php echo e(route('movimentacoes.create')); ?>" class="btn btn-success mb-3">Nova Movimentação</a>

    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <table class="table table-bordered">
        <thead>
            <tr>
                <th>ID</th>
                <th>Requerimento</th>
                <th>Origem</th>
                <th>Destino</th>
                <th>Enviado Por</th>
                <th>Recebido Por</th>
                <th>Status</th>
                <th>Ações</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $movimentacoes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mov): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($mov->id); ?></td>
                    <td><?php echo e($mov->requerimento->titulo ?? 'N/A'); ?></td>
                    <td><?php echo e($mov->setorOrigem->nome ?? 'N/A'); ?></td>
                    <td><?php echo e($mov->setorDestino->nome ?? 'N/A'); ?></td>
                    <td><?php echo e($mov->enviadoPor->name ?? 'N/A'); ?></td>
                    <td><?php echo e($mov->recebidoPor->name ?? '-'); ?></td>
                    <td><?php echo e($mov->status); ?></td>
                    <td>
                        <?php if($mov->status === 'Enviado'): ?>
                            <form action="<?php echo e(route('movimentacoes.receber', $mov)); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <button class="btn btn-primary btn-sm">Receber</button>
                            </form>
                        <?php else: ?>
                            <span class="text-success">Recebido</span>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\requerimento_faculdade_meta\resources\views/movimentacoes/index.blade.php ENDPATH**/ ?>